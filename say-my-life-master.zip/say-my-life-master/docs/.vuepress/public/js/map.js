export function map(ak) {
    
}