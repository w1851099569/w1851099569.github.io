<template>
  <el-image style="width:400px;height:200px">
    <div class="image-slot" slot="error" style="width: 100%;height: 100%;margin: 10px 0;">
      <div class="el-image__error">没有照片</div>
    </div>
  </el-image>
</template>