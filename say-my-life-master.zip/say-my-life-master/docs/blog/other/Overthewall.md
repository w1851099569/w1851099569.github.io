---
pageClass: blog
---

## 如何优雅上网
<p class="date">2020-04-03 16:00
  <span id="/blog/other/Overthewall.html" class="leancloud_visitors">
      <i class="shni shn-eye-fill" />
      <i class="leancloud-visitors-count"></i>
  </span>
</p>

### 1.首先得买一个VPN。

这边推荐一个网站，国内也可以登录，支持支付宝付款。

<a href="https://justmysocks2.net/" target="_blank">Just My Socks</a>

<blockquote>
<p>登录 -> 菜单栏服务 -> 订购新服务 -> 如果没有什么特殊要求选5.88$的就足够用了</p>
</blockquote>

### 2.还得有个工具。

推荐下载<code class="default">Potatso Lite</code>

iOS国区apple id是没有的，得切换到美区账号下载，美区账号这边有<a href="https://github.com/v2net/Apple" target="_blank">共享账号</a>，如果失效的话可以自己去百度一下

### 3.接下来就是科学了。

打开 <code class="default">Potatso Lite</code>

点右上角加号，选择二维码

打开 <a href="https://justmysocks2.net/" target="_blank">Just My Socks</a>

用app扫订单上的各种二维码就行啦

添加成功之后选择一个已经添加的VPN服务器，点击右下角start，现在就可以愉快的谷歌了，建议各位科学上网是用来学习的哦

<base-valine />