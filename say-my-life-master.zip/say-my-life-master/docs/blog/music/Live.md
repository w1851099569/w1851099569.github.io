---
pageClass: blog
---

## 超级喜欢这些LIVE 赶紧安利
<p class="date">2020-04-26 17:30 
  <span id="/blog/music/Live.html" class="leancloud_visitors">
      <i class="shni shn-eye-fill" />
      <i class="leancloud-visitors-count"></i>
  </span>
</p>

##### 春秋 - 张敬轩 
<br/>
<iframe src="//player.bilibili.com/player.html?aid=2258941&bvid=BV1ns411D7Fm&cid=3519407&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" 
allowfullscreen="true" class="bilibili"> </iframe>

##### 彩虹 - 上海彩虹室內合唱团 
<br/>
<iframe src="//player.bilibili.com/player.html?aid=3655775&bvid=BV1ms411R7DC&cid=5849527&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" class="bilibili"> </iframe>

##### 雪之华 - 中岛美嘉 
<br/>
<iframe src="//player.bilibili.com/player.html?aid=2643840&bvid=BV1ds411272u&cid=4127914&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" class="bilibili"> </iframe>

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>