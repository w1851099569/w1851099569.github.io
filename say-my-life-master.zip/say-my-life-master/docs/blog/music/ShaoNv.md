---
pageClass: blog
---

## 少女 - 林宥嘉
<p class="date">2020/06/02 14:03:44 
<span id="/blog/music/ShaoNv.html" class="leancloud_visitors">
    <i class="shni shn-eye-fill" />
    <i class="leancloud-visitors-count"></i>
</span>
</p>

每次见到你 忍不住 超超超愿意

<audio controls="controls" playsinline="" webkit-playsinline="">
    <source src="http://music.163.com/song/media/outer/url?id=1392925633.mp3" type="audio/mpeg">
</audio>

```
作曲 : 林宥嘉
作词 : 黄伟文/林宥嘉
我想要买一间房子
可能不需要车子
最好生一两个孩子
来复制我们的样子

作为一个平凡的男子
我对童话的婚礼有点坚持
跟你才约会一次
人生从此没其他大事

Baby自从遇见你 我比你还要少女
偶像的位置 一夜间 全都换成……
你和巧克力 为什么永远吃不腻
What have you done to me

Baby恋爱的男子 每一个都是少女
每次见到你 忍不住 超超超愿意
Do～Do～Yeah
方圆百里 都懂我的心

浪漫的爱情再定义
快乐回到三年级
自以为完整的身体
突然间倒带再发育

魔羯巨蟹该不该一起
说不配的要道歉还来得及
我们不需要奇迹
因为我是那么适合你

Baby自从遇见你 我比你还要少女
偶像的位置 一夜间 全都换成……
你和巧克力 为什么永远吃不腻
What have you done to me

Baby恋爱的男子 每一个都是少女
每次见到你 忍不住 超超超愿意
Do～Do～Yeah
我只等你 回我同一句

Baby做我的爱妻 一百岁还是少女
有没有勇气 从今后让我照顾你

此情不渝
永结同心
再也不是
空洞的成语

我想要买一间房子
里面住两个少女

OP: HIM Music Publishing Inc.
OP: Wyman Limited (Warner Chappell Music, Hong Kong Limited)
SP: Warner Chappell Music, Hong Kong Limited Taiwan Branch
```

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>
