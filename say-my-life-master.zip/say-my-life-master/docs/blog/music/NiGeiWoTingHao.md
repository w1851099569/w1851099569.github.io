---
pageClass: blog
---

## 你给我听好 - 陈奕迅
<p class="date">2020/08/03 16:13:28 
<span id="/blog/music/NiGeiWoTingHao.html" class="leancloud_visitors">
    <i class="shni shn-eye-fill" />
    <i class="leancloud-visitors-count"></i>
</span>
</p>

你给我听好 想哭就要笑

<audio controls="controls" playsinline="" webkit-playsinline="">
    <source src="http://music.163.com/song/media/outer/url?id=28481103.mp3" type="audio/mpeg">
</audio>

```
作曲 : 林俊杰
编曲：吴庆隆
制作人：林俊杰
配唱制作：林俊杰
制作协力：周信廷 / Gary Lao
钢琴：吴庆隆
第一小提琴：孔朝晖 / 顾文丽 / 隋晶晶
第二小提琴：张振山 / 尹淑占 / 孔宪隆
中提琴：关旗 / 水兵
大提琴：王言 / 郭皓
录音室：白金录音室 (台北) / Yellow Box (Singapore)
录音师：蒋自强 / Gary Leo with Frank Lee & Grocki
混音室：白金录音室 (Taipei)
混音师：林正忠
OP：JFJ Productions Corp. / EMI Music Publishing (S.E. Asia) Ltd., Taiwan Branch
SP：Universal Music Publishing Ltd. Taiwan /
EMI Music Publishing (S.E. Asia) Ltd., Taiwan Branch
你看看大伙儿合照
就你一个人没有笑
是我们装傻 还是你真的
有很多普通人没有的困扰

我才懒得给你解药
反正你爱来这一套
为爱情折腰 难道不是你
一直以来戒不掉的癖好
你在想谁想到睡不着
你应该觉得骄傲
很多人想失恋也没有目标
只是想睡个好觉 别炫耀
别说你还好 没什么不好
你就怨日子枯燥
没什么烦恼 恐怕就想到
什么生存意义想到没完没了
你给我听好 想哭就要笑
其实你知道 烦恼会解决烦恼
新的刚来到 旧的就忘掉
渺小的控诉
就是你想要的生活情调

还会有人让你睡不着
还能为某人燃烧
我亲爱的这样浪漫的煎熬
不是想要就能要 别炫耀
别说你还好 没什么不好
你就怨日子枯燥

没什么烦恼 恐怕就想到
什么生存意义想到没完没了
你给我听好 想哭就要笑
其实你知道 烦恼会解决烦恼
新的刚来到 那旧的就忘掉
渺小的控诉
只是证明生活并不无聊

别说你还好 没什么不好
你就怨日子枯燥

没什么烦恼 恐怕就想到
什么生存意义想到没完没了
你给我听好 想哭就要笑
其实你知道 烦恼会解决烦恼
新的刚来到 旧的就忘掉
渺小的控诉
只是证明生活并不无聊

别让我知道
其实你在背着我们偷笑
```

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>
