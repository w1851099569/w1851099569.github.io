---
pageClass: blog
---

## 记得 - 林俊杰
<p class="date">2020-04-30 10:30 
  <span id="/blog/music/Jide.html" class="leancloud_visitors">
      <i class="shni shn-eye-fill" />
      <i class="leancloud-visitors-count"></i>
  </span>
</p>

谁还记得是谁先说，永远的爱我

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=25638971&auto=1&height=66"></iframe>

```
谁还记得是谁先说
永远的爱我
以前的一句话 是我们
以后的伤口
过了太久没人记得
当初那些温柔
我和你手牵手
说要一起
走到最后


我们都忘了
这条路走了多久
心中是清楚的
有一天 有一天都会停的

让时间说真话
虽然我也害怕
在天黑了以后
我们都不知道
会不会有以后

谁还记得是谁先说
永远的爱我
以前的一句话 是我们
以后的伤口
过了太久没人记得
当初那些温柔
我和你手牵手
说要一起
走到最后

我们都累了
却没办法往回走
两颗心都迷惑
怎么说 怎么说都没有救

亲爱的为什么
也许你也不懂
两个相爱的人
等着对方先说
想分开的理由

谁还记得爱情开始
变化的时候
我和你的眼中看见了
不同的天空
走得太远终于走到
分岔路的路口
是不是你和我
要有两个 相反的梦

谁还记得是谁先说
永远的爱我
以前的一句话 是我们
以后的伤口
过了太久没人记得
当初那些温柔
我和你手牵手
说要一起
走到最后

我和你手牵手
说要一起
走到最后
```

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>