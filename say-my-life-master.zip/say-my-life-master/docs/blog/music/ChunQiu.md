---
pageClass: blog
---

## 春秋 - 张敬轩
<p class="date">2020-05-08 17:36:36 
<span id="/blog/music/ChunQiu.html" class="leancloud_visitors">
    <i class="shni shn-eye-fill" />
    <i class="leancloud-visitors-count"></i>
</span>
</p>

动人像友情深了,我没权终止见面

<audio controls="controls" playsinline="" webkit-playsinline="">
    <source src="http://music.163.com/song/media/outer/url?id=188325.mp3" type="audio/mpeg">
</audio>

```
作曲 : Edmond Tsang
作词 : 林夕
编曲：C.Y. Kong
那夜谁将酒喝掉

因此我讲得多了

然后你摇着我手拒绝我

动人像友情深了
我没权终止见面

只因你友善依然

仍用接近甜蜜那种字眼通电

没人应该怨地怨天
得到这结局

难道怪罪神没有更伪善的祝福

我没有为你伤春悲秋不配有憾事
你没有共我踏过万里
不够剧情延续故事

头发未染霜 着凉亦错在我幼稚

应快活像个天使

有没有运气再扮弱者玩失意

有没有道理为你落发
必须得到世人同意
心灰得极可耻 心伤得无新意
那一线眼泪 欠大志

爱若能堪称伟大

再难挨照样开怀

如令你发现为你而活到失败

令人不安 我品性坏
我没有为你伤春悲秋不配有憾事
你没有共我踏过万里
不够剧情延续故事

头发未染霜 着凉亦错在我幼稚
应快活像个天使
有没有运气再扮弱者玩失意
有没有道理为你落发
必须得到世人同意

心灰得极可耻 心伤得无新意
那一线眼泪 欠大志
太没意思

若自觉这叫痛苦未免过份容易
我没有被你改写一生怎配有心事
我没有被你害过恨过
写成情史变废纸

春秋只转载要事 如果爱你欠意义

这眼泪无从安置
我没有运气放大自私的失意
更没有道理在这日
你得到真爱制造恨意
想心酸还可以 想心底留根刺

至少要见面上万次
```

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>
