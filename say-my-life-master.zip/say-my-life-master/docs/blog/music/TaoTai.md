---
pageClass: blog
---

## 淘汰 - 陈奕迅
<p class="date">2020-05-21 14:14:04 
<span id="/blog/music/TaoTai.html" class="leancloud_visitors">
    <i class="shni shn-eye-fill" />
    <i class="leancloud-visitors-count"></i>
</span>
</p>

只能说我输了，也许是你怕了

<audio controls="controls" playsinline="" webkit-playsinline="">
    <source src="http://music.163.com/song/media/outer/url?id=65528.mp3" type="audio/mpeg">
</audio>

```
作曲 : 周杰伦
作词 : 周杰伦
我说了 所有的谎
你全都相信
简单的 我爱你
你却老不信
你书里的剧情
我不想上演
因为我喜欢 喜剧收尾

我试过 完美放弃
的确很踏实
醒来了
梦散了
你我都走散了
情歌歌词何必押韵
就算我是K歌之王
也不见得把 爱情唱得完美

只能说我输了
也许是你怕了
我们的回忆 没有皱褶
你却用离开烫下句点
只能说我认了
你的不安赢得你信任
我却得到你 安慰的淘汰

我试过完美放弃
的确很踏实
醒来了
梦散了
你我都走散了
情歌歌词何必押韵
就算我是K歌之王
也不见得把 爱情唱得完美

只能说我输了
也许是你怕了
我们的回忆 没有皱褶
你却用离开烫下句点
只能说我认了
你的不安赢得你信任
我却得到你 安慰的淘汰
只能说我输了
也许是你怕了
我们的回忆 没有皱褶
你却用离开烫下句点
只能说我认了
你的不安赢得你信任
我却得到你 安慰的淘汰
```

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>
