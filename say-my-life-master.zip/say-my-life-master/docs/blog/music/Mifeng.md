---
pageClass: blog
---

## 蜜蜂 - 万岁爺
<p class="date">2020-04-26 17:30 
  <span id="/blog/music/Mifeng.html" class="leancloud_visitors">
      <i class="shni shn-eye-fill" />
      <i class="leancloud-visitors-count"></i>
  </span>
</p>

伟大的人都靠想象

<audio controls="controls" playsinline="" webkit-playsinline="">
    <source src="http://music.163.com/song/media/outer/url?id=40249612.mp3" type="audio/mpeg">
</audio>

```
作曲 : annett万岁爺
作词 : annett万岁爺

好想被风刮走
刮遍整个地球的那种
在我爱的城市停 走 停 走
是谁把冲动 说成青春期躁动
以为还十五六
一个人易沉默
两个人太啰嗦
有话题的时候认定你是好朋友
如果灿烂星空 自己不够闪烁
才不会担心坠落那么多
别带我到太高太远太险我看不见的地方
白雾山岗总有蜘蛛网
没有人在身旁指引方向
原来我只是看起来匆忙
别把我的失眠时间拖延一个礼拜以上
记忆力又下降
明明说好早起看太阳又生怕遗忘
所以随时随地竖起我翅膀
从家门口路过没我要的花朵
可十几年来一直在汲取着
趁着你的肩膀还能撑得起重量
就让我在天上飞
你说生命不长 一眨眼就用光
才不敢犹豫不决后悔或是彷徨
有几个晚上 想看夜空星光
可我却飞不过这紧闭纱窗
别带我到太高太远太险我看不见的地方
站越高越紧张
我想在天空飞翔 却发出刺耳声响
伟大的样子都靠想象
原谅我背负了一些你不知道的远大理想
一件比一件疯狂
你以为那些会是你做不到的事
没抱希望怎么懂失望
你我一模一样
梦想不同凡响
如今你放弃我还在幻想
你爱装模作样
说自己很善良
明明伤害谁你也活不长
```

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>