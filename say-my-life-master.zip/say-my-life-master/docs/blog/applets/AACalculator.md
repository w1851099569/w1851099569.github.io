---
pageClass: blog
---

## 安利一个我自己写的小程序：AA计算器
<p class="date">2020-04-17 15:00
  <span id="/blog/applets/AACalculator.html" class="leancloud_visitors">
      <i class="shni shn-eye-fill" />
      <i class="leancloud-visitors-count"></i>
  </span>
</p>

你们有没有在好多个基友一起旅行或者购物的时候算钱非常麻烦！

快来使用这个小程序吧，AA制计算器 ，给个例子。

A消费了200，B消费了100，C消费了400，D消费了0。

结果会是：

```
B支付A：25元。
B支付C：50元。
D支付C：175元。
```

这会是最简单的转账流程，减少了你和小伙伴们算来算去的麻烦，我深有体会！！

微信扫二维码就可以使用了哟

![avatar](https://cdn.chenyingshuang.cn/blog/applets/AACalculator/1.jpg?imageView2/1/w/200)

<base-valine />