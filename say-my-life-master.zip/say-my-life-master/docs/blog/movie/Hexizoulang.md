---
pageClass: blog
---

## 纪录片 - 河西走廊
<p class="date">2020-05-07 14:00 
  <span id="/blog/movie/HeXiZouLang.html" class="leancloud_visitors">
      <i class="shni shn-eye-fill" />
      <i class="leancloud-visitors-count"></i>
  </span>
</p>

::: tip 简介
《河西走廊》是一部由中共甘肃省委宣传部、中央电视台科教频道联合出品，北京伯璟文化传播有限公司承制的十集系列纪录片。该片以位于中国西部的重要通道，丝绸之路的黄金段——河西走廊为讲述对象，从政治、军事、经济、文化、宗教等多角度呈现了从汉代开始直至今天，河西走廊及其连接的中国 西部 的历史，以及它对中国历史和文明进程中所发挥的独特作用。“河西走廊关乎国家经略”是贯穿全篇的主题。
:::

<iframe frameborder="0" src="https://v.qq.com/txp/iframe/player.html?vid=b0027n5tqon" allowFullScreen="true" class="tencent-video"></iframe>

<base-valine />
<el-backtop :visibility-height="0"></el-backtop>