---
home: true
pageClass: index
# heroImage: /img/index-logo.gif
# features:
# - title: 记录生活
#   details: 做一个热爱生活的人。
# - title: 记录笔记
#   details: 每天都要学习，每天都要成长。
# - title: 记录旅行
#   details: 多出去走走看看，才有资格拥有诗和远方。
# footer: Happy Life Copyright © 2019-present Sang Hang Ning
---



<index />