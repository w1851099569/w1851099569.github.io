---
pageClass: diary
---

## VsCode 常用插件

### 
Chinese (Simplified) Language Pack for Visual Studio Code - 中文（简体）语言包 <br>
Import Cost - 导入文件大小<br>
vscode-fileheader - 自动记录文件修改时间 - CTRL+ALT+I<br>
vscode-icons - vscode风格文件icon<br>
Beautify - 自动格式化代码<br>

### 前端
Vetur <br>
javascript console utils - 快速console - CTRL+SHIFT+L<br>
Live Server - 静态网页开启服务<br>
open in browser - 快速开启浏览器浏览网页 - ALT+B<br>
Better Comments - 不同风格注释<br>

### Git
Git History<br>
