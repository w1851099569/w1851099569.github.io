---
pageClass: animation-no-title
---

## 有趣动画 - 颜色形状

<animation-shapescolor />