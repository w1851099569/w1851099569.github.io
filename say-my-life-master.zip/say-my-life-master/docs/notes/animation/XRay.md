---
pageClass: animation-no-title
---

## 有趣动画 - X光透视人体

<animation-xray />